/* 
Programmer: Alex Durso

Program Name: LotteryDemo.java

Date: 12/8/2015

Purpose: Demonstrates lottery class by asking user to enter five numbers. The program then displays
the amount of digits that match the randomly generated lottery numbers. If all digits match a message
displays that the user has won the grand prize.

Met Specifications: Yes

Psuedocode:
1. Define variables for
   a. Number of digits on a lottery ticket
   b. Number of matching numbers between winning and user lottery ticket
   c. Create array to hold user inputs
   d. Array that will hold winning numbers from lottery class

2. (Input) Request user input for the following information
   a. 5 digits between 1 and 9 to serve as user's lottery ticket
   
3. (Processing - Calculations)
   a. Assign user input array to correct length
   b. Assign user inputs to userPicks array
   c. Validate that user input is in correct range
   d. Determine number of matching numbers between user and winning ticket
   e. Determine if user matched all numbers correctly to receive prize

4. (Output)
   a. Winning numbers
   b. The number of numbers the user matched
   c. If user matched all numbers output congratulations 


*/
import java.util.Scanner; //Makes scanner class available

public class LotteryDemo 
{
	public static void main(String[] args)
	{
      //Declare variables
		int lotto_size = Lottery.NUM_DIGITS;
		int matching; //Holds number of matching
      
      //Create userPicks array to hold user input
		int[] userPicks = new int[lotto_size];
      
		//Create new scanner object to receive user input				
		Scanner keyboard = new Scanner(System.in);
		
		//Create a lottery object
		Lottery lotto = new Lottery();
		
      //Greet lottery contestant
      System.out.println("Welcome to the lottery! Please enter five digits between zero and nine.");
      System.out.println("Your choices will then be compared with the winning ticket.");
      
		//Create for loop to get user picks
		for (int i=0; i<lotto_size; i++)
		{
			System.out.print("Enter digit " + (i+1) + ": ");
			userPicks[i] = keyboard.nextInt();
         
			//Setup validation to test that numbers are in the correct range
			while (userPicks[i]<0 || userPicks[i]>9)
			{
				System.out.println("That number is incorrect! Please select a number between zero and nine: ");
				userPicks[i] = keyboard.nextInt();
			}
		}
		
		//Determine number of matching numbers
		matching = lotto.numMatching(userPicks);
		
      //Create winningNums array to hold winning numbers
		int[] winningNums = lotto.copy();
      
		//Display winning lottery numbers
		System.out.print("Winning numbers: ");
		
      //Use for loop to display contents of the array
		for (int i=0; i<lotto_size; i++)
		{
			System.out.print(winningNums[i] + " ");
		} 
		System.out.println(); 	
		
      //Output user's results
		System.out.println("You have " + matching + " matching numbers");
		
      //Test if user got all numbers correct
		if(matching == lotto_size)
		{
			System.out.println("You have won the Grand Prize!");
		}
	}
}