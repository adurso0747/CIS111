/* 
Programmer: Alex Durso

Program Name: Lottery.java

Date: 12/8/2015

Purpose: Generates a random array of numbers to be used as a winning lottery ticket and allows user
to play a lottery game with this array.

Met Specifications: Yes

Psuedocode:
1. Define variables for
   a. Number of digits in the lottery ticket
   b. Array of lottery numbers
   c. Random class
   
2. (Input) - N/A

3. (Proccessing - Calculations)
   a. Assign lottery numbers array to correct amount of digits
   b. Generate random numbers for lottery numbers array
   c. Assign random numbers to lottery numbers array
   d. Determine number of matching numbers from winning ticket and user ticket
   e. Copy lottery numbers array so it can be referenced in lotterydemo
   
4. (Output) - N/A

*/


import java.util.Random; //Allows random class to be used

public class Lottery 
{
	//Declare constant for the number of digits in the lottery ticket
	public static final int NUM_DIGITS = 5;
	
	//Array to hold the lottery numbers
	private int[] lotteryNumbers;
	
	/**
	 * Constructor
	 */
	public Lottery()
	{
      //Creates new method to hold lotteryNumbers
		lotteryNumbers = new int[NUM_DIGITS];
      
      //Generates random numbers for winning lottery ticket
		Random rand = new Random();
		
      //Assigns random numbers to lotteryNumbers array
		for(int i=0; i<NUM_DIGITS; i++)
		{
			lotteryNumbers[i] = rand .nextInt(9);
		}
	}
	/*
	 * numMatching method
	 * Returns the number of digits in the
	 * users pick that match the winning numbers
	 */
	
	public int numMatching(int[] picks)
	{
		int num = 0; //accumulate # of matching
		
      //Loop to determine number of matching
		for(int i=0; i<NUM_DIGITS; i++)
		{
			if(picks[i] == lotteryNumbers[i])
			{
				num++;
			}
		}
		return num;
	}
	
	/*
	 * copy method
	 */
	
	public int[] copy()
	{
		int[] arr = new int[NUM_DIGITS];
		
      //Loop that copies lotteryNumbers array to arr array
		for (int i=0; i<NUM_DIGITS; i++)
		{
			arr[i] = lotteryNumbers[i];
		}
		
		return arr;
	}
}