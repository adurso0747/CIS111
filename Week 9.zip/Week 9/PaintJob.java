/* 
Programmer: Alex Durso

Program Name: PaintJob.java

Date: 11/03/2015

Purpose: A painting company has determined that for every 115 sqft of wall space, 1 gallon of paint and 8 hrs of labor are required.
   The company charges $18/hr for labor.
   This program allows the user to enter the number of rooms to be painted and the price of the paint per gallon.
   It also asks for the square feet of wall space in each room.
   At the end of the program the total price of the paint job is displayed.

Met Specifications: Yes

Program pseudocode: 
1. Define Variables for
   a. Total amount of rooms
   b. Square feet of wall space 
   c. Price of the paint per gallon
   d. Total gallons required for the paint job
   e. Total hours required for the paint job
   f. Total cost of the paint
   g. Total cost of the labor
   h. Total cost overall
   
2. (Input) Request user input for the following information
   a. Total amount of rooms
   b. Square feet of wall space
   c. Price per gallon of paint
   
3. (Processing - Calculations)
   a. Gallons of paint required = Square feet/115
   b. Hours required = (squarefeet/115) * 8
   c. Total paint cost = gallons * price per gallon
   d. Total labor charge = hours required * 18
   e. Total cost = total labor charge + total paint cost

4. (Output) Format output to display
   a. Total number of gallons needed - double calculated in processing in number format
   b. Total number of work hours - double calculated in processing in number format
   c. Total paint cost - double calculated in processing in currency format
   d. Total labor charge - double calculated in processing in currency format
   e. Total cost of the job - double calculated in processing in currency format.
   

*/

import java.util.Scanner; //This makes the scanner class available
import java.text.NumberFormat; //This makes the number format class available

public class PaintJob
{
  
    public static void main(String[] args)
    {
        //Declare variables
        int totalRooms = 0;
        double squareFeet = 0.0;
        double pricePerGallon = 0.0;
        double totalGallonsRequired = 0.0;
        double totalHoursRequired = 0.0;
        double totalPaintCost = 0.0;
        double totalLaborCharge = 0.0;
        double totalCost = 0.0; 
        
        //Create new scanner for user input
        Scanner userInput = new Scanner(System.in);
        
        //Create a number and currency formatter
        NumberFormat nf = NumberFormat.getInstance();
        NumberFormat cf = NumberFormat.getCurrencyInstance();
        
        //Prompt user for total number of rooms to be painted
        System.out.print("\nEnter the total number of rooms to be painted: ");
        
        //Verify user has entered a valid number
        if (!userInput.hasNextInt()) 
        { 
         System.out.println("You must enter a number, greater than 1."); 
         System.exit(1); 
        }
        
        //Store number of rooms
        totalRooms = userInput.nextInt();
        
        //Verify user has entered a number greater than 1
        if (totalRooms < 1) 
        { 
         System.out.println("There must be at least 1 room!"); 
         System.exit(1); 
        }
        
        //Ask user for the price of each gallon of paint.
        System.out.print("Enter the price of each gallon of paint: ");
        
        //Verify user has entered a valid number
        if (!userInput.hasNextDouble()) 
        { 
         System.out.println("You must enter a valid price, greater than $1.00."); 
         System.exit(1); 
        }
        
        //Store the price per gallon of the paint
        pricePerGallon = userInput.nextDouble();
        
        if(pricePerGallon <= 0)
        { 
         System.out.println("You must enter a valid price, greater than $0.00."); 
         System.exit(1); 
        }
        
        
        //Use loop to ask user for square feet of each room 
        for (int i = 1; i <= totalRooms; i++)
        {
          System.out.print("How many square feet of wall space are in room # " + i + ": ");
          
          //Verify user has entered a valid number
          if (!userInput.hasNextDouble()) 
          { 
          System.out.println("You must enter a number."); 
          System.exit(1); 
          }
          
          //Store the room's square feet
          squareFeet = userInput.nextDouble();
          
          //Verify user has entered a number greater than 1
          if (squareFeet < 1) 
          { 
          System.out.println("There must be at least 1 square foot to paint."); 
          System.exit(1); 
          }
          
          //Calculate the number of gallons of paint required by using the getGallonsRequired() method 
          totalGallonsRequired += getGallonsRequired(squareFeet);
          
          //Calculate the number of hours of work required by using the getHoursRequired() method
          totalHoursRequired += getHoursRequired(squareFeet);
        }
        
        //Calculate total cost of the paint by using the getTotalPaintCost() method
        totalPaintCost = getTotalPaintCost(totalGallonsRequired, pricePerGallon);
        
        //Calculate total labor charge by using the getTotalLaborCharge() method
        totalLaborCharge = getTotalLaborCharge(totalHoursRequired);
        
        //Calculate total cost of the paint job by using the getTotalCost() method
        totalCost = getTotalCost(totalPaintCost, totalLaborCharge);
        
        //Output all details about this paint job to user.
        System.out.println("\nTotal number of gallons needed: " + nf.format(totalGallonsRequired));
        System.out.println("Total number of work hours: " + nf.format(totalHoursRequired));
        System.out.println("Total paint cost: " + cf.format(totalPaintCost));
        System.out.println("Total labor charge: " + cf.format(totalLaborCharge));
        System.out.println("\nTotal cost for the paint job: " + cf.format(totalCost) + "\n");
        
    } 
    
    //Methods:
    //getGallonsRequired() - Calculates gallons of paint required
    public static double getGallonsRequired(double sqft)
    {
      double gallons = 1;
        gallons = sqft / 115;
        return gallons;
    }
    
    //getHoursRequired() - Calculates hours of labor required
    public static double getHoursRequired(double sqft)
    {
      double hours = 8;
      hours *= (sqft / 115);
      return hours;
    }
    
    //getTotalPaintCost() - Calculates cost of the paint
    public static double getTotalPaintCost(double gallons, double cost)
    {
      double result = gallons * cost;
      return result;
    }
    
    //getTotalLaborCharge() - Calculates total labor charges
    public static double getTotalLaborCharge(double hours)
    {
      double result = hours * 18;
      return result;
    } 
    
    //getTotalCost() - Calculates total cost of the paint job
    public static double getTotalCost(double paintCost, double laborCharge)
    {
      double result = paintCost + laborCharge;
      return result;
    } 
    
} 