/* 
Programmer: Alex Durso

Program Name: AreaRectangle.java

Date: 11/03/2015

Purpose: Calculate the area of a rectangle from variables input by user.

Met Specifications: Yes

Program pseudocode: 
1. Define Variables for
   a. Length
   b. Width
   c. Area
   
2. (Input) Request user input for the following information
   a. Length
   b. Width
   
3. (Processing - Calculations)
   a. Area = Length * Width

4. (Output) Format output to display
   a. Length - double from user input
   b. Width - double from user input
   c. Area - double calculated by multiplying length and width 
   

*/

import java.util.Scanner; //This statement makes scanner available 
public class AreaRectangle
{
   public static void main(String[] args)
   {
      //Declare variables
      double length = 0.0;
      double width = 0.0;
      double area = 0.0;
   
      //Get rectangle's length from user.
      length = getLength();
   
      //Get rectangle's width from user.
      width = getWidth();

      //Get rectangle's area.
      area = getArea(length, width);

      // Display the rectangle data.
      displayData(length, width, area);
   }
   
   /**
   getLength() method
   Method which asks user for length of rectangle then returns
   that length as a double.
   */
   public static double getLength()
   {
     System.out.print("Enter the length of the rectangle: ");
     Scanner userInput = new Scanner(System.in);
     
     //Verify user has entered a valid number
     if (!userInput.hasNextInt())
     {
      System.out.println("You did not enter a valid number!");
      System.exit(1);
     }
     
 
     //Store user number
     double ret = userInput.nextInt();
     
     //Verify user entered a vaild number
     if (ret <= 0)
     {
      System.out.println("You did not enter a valid number!");
      System.exit(1);
     }
     
     //Return number
     return ret;
   }
   
   /**
   getWidth() method
   Method which asks the user for width of rectangle then 
   returns this value as a double.
   */
   public static double getWidth()
   {
     System.out.print("Enter the width of the rectangle: ");
     Scanner userInput = new Scanner(System.in);
     
      //Verify user entered a valid number
      if (!userInput.hasNextInt())
      {
       System.out.println("You did not enter a valid number!");
       System.exit(1);
      }

      //Store number entered by user
      double ret = userInput.nextInt();

     //Verify user entered a vaild number
     if (ret <= 0)
     {
      System.out.println("You did not enter a valid number!");
      System.exit(1);
     }
     
      //Return number
      return ret;
   }
   
   /**
    getArea() method
    Method which accepts two arguments of type double then multiplies them.
    It returns the result as a double.
    */
   public static double getArea(double l, double w)
   {
     double result = l * w;
     return result;
   }
   
   /**
    displayData() method
    Method which accepts 3 doubles as arguments and prints them with
    println()
    */
   public static void displayData(double l, double w, double a)
   {
     System.out.println("The length is: " + l);
     System.out.println("The width is: " + w);
     System.out.println("The area is: " + a);
   }
}
